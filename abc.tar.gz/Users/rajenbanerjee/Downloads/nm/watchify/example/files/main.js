var one = require('./one');
console.log(one(5));
